const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/LMSdb', { useNewUrlParser: true, useUnifiedTopology: true });

// Define a schema and model for courses
const courseSchema = new mongoose.Schema({
    courseId: Number,
    courseName: String,
    studentCount: { type: Number, default: 0 },
    students: [{ studentId: Number, grade: Number }]
});
const Course = mongoose.model('Course', courseSchema);

// API endpoint to create a course
app.post('/createCourse', async (req, res) => {
    const { courseId, courseName } = req.body;
    const course = new Course({ courseId, courseName });
    try {
        await course.save();
        res.status(201).send('Course created successfully');
    } catch (error) {
        res.status(400).send('Error creating course');
    }
});

// API endpoint to get course details
app.get('/course/:courseId', async (req, res) => {
    const { courseId } = req.params;
    try {
        const course = await Course.findOne({ courseId });
        if (course) {
            res.status(200).json(course);
        } else {
            res.status(404).send('Course not found');
        }
    } catch (error) {
        res.status(400).send('Error fetching course details');
    }
});

// API endpoint to enroll a student in a course
app.post('/enrollStudent', async (req, res) => {
    const { courseId, studentId } = req.body;
    try {
        const course = await Course.findOne({ courseId });
        if (course) {
            course.studentCount = (course.studentCount || 0) + 1;
            course.students.push({ studentId, grade: null });
            await course.save();
            res.status(200).send('Student enrolled successfully');
        } else {
            res.status(404).send('Course not found');
        }
    } catch (error) {
        res.status(400).send('Error enrolling student');
    }
});

// API endpoint to assign a grade to a student
app.post('/assignGrade', async (req, res) => {
    const { courseId, studentId, grade } = req.body;
    try {
        const course = await Course.findOne({ courseId });
        if (course) {
            const student = course.students.find(student => student.studentId === studentId);
            if (student) {
                student.grade = grade;
                await course.save();
                res.status(200).send('Grade assigned successfully');
            } else {
                res.status(404).send('Student not found in this course');
            }
        } else {
            res.status(404).send('Course not found');
        }
    } catch (error) {
        res.status(400).send('Error assigning grade');
    }
});

// API endpoint to get the total number of courses
app.get('/totalCourses', async (req, res) => {
    try {
        const totalCourses = await Course.countDocuments();
        res.status(200).send(totalCourses.toString());
    } catch (error) {
        res.status(400).send('Error fetching total courses');
    }
});

const PORT = 5500;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

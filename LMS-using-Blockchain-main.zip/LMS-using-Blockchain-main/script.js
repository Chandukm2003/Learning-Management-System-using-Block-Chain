const LearningManagementSystem = artifacts.require("LearningManagementSystem");

module.exports = async function() {
  try {
    // Get deployed contract instance
    const LMS = await LearningManagementSystem.deployed();
    
    // Example addresses
    const instructor = "0x4C4C8a5Cb3ecF33f2348444484d1AC6cbBA4CaD8"; // Replace with actual instructor address
    const student = "0x7a77A12832909d88d3FaA4d09bDC3a6054970ae6"; // Replace with actual student address

    // Register a new course
    console.log("Registering a new course...");
    await registerCourse(LMS, "Introduction to Blockchain");

    // Enroll student to the course
    console.log("Enrolling student to the course...");
    await enrollStudent(LMS, 1, student);

    // Assign grade to the student
    console.log("Assigning grade to the student...");
    await assignGrade(LMS, 1, student, 85);

    // Retrieve student details
    console.log("Retrieving student details...");
    await getStudentDetails(LMS, 1, student);
  } catch (error) {
    console.error("Error executing script:", error);
  }
};

async function registerCourse(LMS, courseName) {
  const tx = await LMS.createCourse(courseName);
  console.log("Course registered successfully:", courseName);
  console.log("Transaction receipt:", tx);
}

async function enrollStudent(LMS, courseId, studentAddress) {
  const tx = await LMS.enrollStudent(courseId, studentAddress);
  console.log("Student enrolled successfully to Course ID:", courseId);
  console.log("Transaction receipt:", tx);
}

async function assignGrade(LMS, courseId, studentAddress, grade) {
  const tx = await LMS.assignGrade(courseId, studentAddress, grade);
  console.log("Grade assigned successfully to Student:", studentAddress);
  console.log("Transaction receipt:", tx);
}

async function getStudentDetails(LMS, courseId, studentAddress) {
  const courseDetails = await LMS.getCourseDetails(courseId);
  const courseName = courseDetails[0];
  const instructor = courseDetails[1];
  const grade = await LMS.getGrade(courseId, studentAddress);
  console.log(`Student Grade for Course "${courseName}" (ID: ${courseId}): ${grade.toString()}`);
}

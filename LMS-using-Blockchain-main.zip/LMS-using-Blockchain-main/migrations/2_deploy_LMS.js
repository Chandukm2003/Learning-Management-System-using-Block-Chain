// migrations/2_deploy_LMS.js
const LMS = artifacts.require("LearningManagementSystem");

module.exports = function (deployer) {
  deployer.deploy(LMS);
};
